const fs = require('fs');

let rawdata = fs.readFileSync('inventory.json');
let inventoryData = JSON.parse(rawdata);

module.exports = {
    configure: (req, res) => {
        try {
            fs.writeFileSync('inventory.json', JSON.stringify(req.body));
            return res.status(200).send();
        } catch (e) {
            return res.status(500).send("Error while inserting");
        }
    },
    update: (req, res) => {
        try {
            let data = req.body;
            if (data !== undefined && data.temperature !== undefined) {
                if (data.temperature === 20) {
                    let allKeys = Object.keys(inventoryData)
                    for (let key of allKeys) {
                        if (key !== 'temperature' && data[key] !== undefined) {
                            inventoryData[key] = data[key];
                        }
                    }
                    fs.writeFileSync('inventory.json', JSON.stringify(req.body));
                    return res.status(200).send();
                } else {
                    return res.status(400).send("Temperature must be 20");
                }
            } else { 
                return res.status(400).send();
            }
        } catch (e) {
            return res.status(500).send("Error while updating");
        }
    }
}