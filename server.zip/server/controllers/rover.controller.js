const fs = require('fs');


module.exports = {
    move: (req, res) => {
        let rawdata = fs.readFileSync('rover.json');
        let roverData = JSON.parse(rawdata);

        let rawInventorySamples = fs.readFileSync('inventory_sample.json');
        let roverInventorySampleData = JSON.parse(rawInventorySamples);

        let rawInventorydata = fs.readFileSync('inventory.json');
        let roverInventoryData = JSON.parse(rawInventorydata);

        let rawLocationdata = fs.readFileSync('roverlocation.json');
        let roverLocationData = JSON.parse(rawLocationdata);

        //if strom true
        if (roverData !== undefined && roverInventoryData.storm) {
            let message = {
                "message": "Cannot move during a storm"
            }
            collectSample(roverInventorySampleData, roverLocationData, "storm-shield", 1);
            fs.writeFileSync('roverlocation.json', JSON.stringify(roverLocationData));
            return res.status(428).send(message);
        }

        let rowSize = roverInventoryData['area-map'].length;
        let colSize = roverInventoryData['area-map'][0].length;
        let reqBody = req.body;
        if (reqBody !== undefined && reqBody.direction !== undefined) {
            let currentLocation = roverLocationData.rover.location;
            let row = currentLocation.row;
            let col = currentLocation.column;

            //get the possible direction to be move
            let possibleDirection = getPossibleMoveDirection(row, col, rowSize, colSize);

            if (possibleDirection.length > 0 && possibleDirection.includes(reqBody.direction)) {
                switch (reqBody.direction) {
                    case 'up':
                        row -= 1;
                        break;
                    case 'down':
                        row += 1;
                        break;
                    case 'left':
                        col -= 1;
                        break;
                    case 'right':
                        col += 1;
                        break;
                }
                currentLocation.row = row;
                currentLocation.column = col;
                let terrain = roverInventoryData['area-map'][row][col];

                //update the terrain
                roverLocationData.environment.terrain = terrain;
                let currBattery = roverLocationData.rover.battery;
                let defaulValueOfBattery = roverData['initial-battery'];

                let valueToBesubtracted = currBattery > defaulValueOfBattery ? (currBattery - defaulValueOfBattery) : 0;
                if (currBattery === (defaulValueOfBattery - (9 + valueToBesubtracted))) {
                    //recharge the battery after 10 step
                    currBattery += 10;
                } else {
                    //discharge the battery after 10 step
                    currBattery -= 1;
                }

                //update the battery level
                roverLocationData.rover.battery = currBattery;

                //collectd th sample
                if (currBattery <= 2 && terrain === 'water') {
                    collectSample(roverInventorySampleData, roverLocationData, 'water-sample', 2);
                }
                else if (currBattery <= 2 && terrain === 'rock') {
                    collectSample(roverInventorySampleData, roverLocationData, 'rock-sample', 3);
                } else {
                    collectSample(roverInventorySampleData, roverLocationData, 'rock-sample', 1);
                }
                fs.writeFileSync('roverlocation.json', JSON.stringify(roverLocationData));
                return res.status(200).send("Successfully updated.");
            } else {
                let msg = {
                    "message": "Can move only within mapped area"
                }
                return res.status(428).send(msg);
            }
        } else {
            return res.status(400).send();
        }
    },
    configure: (req, res) => {
        try {
            fs.writeFileSync('rover.json', JSON.stringify(req.body));
            return res.status(200).send();
        } catch (e) {
            return res.status(500).send("Error while configuring.");
        }
    },
    status: (req, res) => {
        try {
            let rawLocationdata = fs.readFileSync('roverlocation.json');
            let roverLocationData = JSON.parse(rawLocationdata);
            return res.status(200).send(roverLocationData);
        } catch (e) {
            return res.status(500).send("Error while retriving status.");
        }

    }
}

function getPossibleMoveDirection(row, col, mapRowSize, mapColSize) {
    let possibleDirection = [];
    if (row === 0 && row < (mapRowSize - 2) || (row > 0) && row <= (mapRowSize - 2)) {
        possibleDirection.push("down");
    }
    if (row > 0) {
        possibleDirection.push("up");
    }
    if ((col === 0 && col <= (mapColSize - 2)) || (col > 0 && col <= (mapColSize - 2))) {
        possibleDirection.push("right");
    }
    if (col > 0) {
        possibleDirection.push("left");
    }
    return possibleDirection;

}


function collectSample(roverInventorySampleData, roverLocationData, sampleName, priority) {
    let sampleObj = roverInventorySampleData.find(item => item.name === sampleName)
    let allUnitsArr = roverInventorySampleData.map(item => item.units);
    let allUnitsCount = allUnitsArr.reduce((item, accum) => item + accum);

    //already inventory added
    let collectedInventoryTotalArr = roverLocationData.rover.inventory.map(item => item.qty);

    //already inventory added items units
    let collectedInventoryTotalCount = collectedInventoryTotalArr.length > 0 ? collectedInventoryTotalArr.reduce((item, accum) => item + accum) : 0;
    
    let inventoryRoverLocationObj = roverLocationData.rover.inventory.find(item => item.name === sampleName);
    if(inventoryRoverLocationObj === undefined) {
        roverLocationData.rover.inventory.push({
            name: sampleName,
            qty: 0,
            priority: priority
        });
    }
    if (inventoryRoverLocationObj !== undefined) {
        if (inventoryRoverLocationObj.qty < allUnitsCount) {
            inventoryRoverLocationObj.qty += 1;
        }
        if (allUnitsCount === collectedInventoryTotalCount) {
            roverInventorySampleData.sort((a, b) => {
                let keyA = a.proirity;
                let keyB = b.proirity;
                if (keyA > keyB) return -1;
                if (keyA < keyB) return 1;
                return 0;
            });
            let removeFlag = false;
            for (let obj of roverInventorySampleData) {
                if (obj.name !== sampleName && obj.proirity < priority) {
                    let objLowestPriorityItem = roverLocationData.rover.inventory.find(item => item.name === obj.name);
                    if (objLowestPriorityItem != undefined && objLowestPriorityItem.qty > 0) {
                        objLowestPriorityItem.qty -= 1;
                        removeFlag = true;
                        break;
                    }
                }
            }
            if (removeFlag) {
                inventoryRoverLocationObj.qty += 1;
            }
        }
    }
}