const inventory = require('./inventory.api');
const rover = require('./rover.api');

module.exports = (router) => {
    inventory(router);
    rover(router);
    return router;
};