const controller = require('../controllers/inventory.controller');

module.exports = (router) => {
    router.route('/environment/configure').post(controller.configure);
    router.route('/environment').patch(controller.update);
};