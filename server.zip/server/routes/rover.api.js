const controller = require('../controllers/rover.controller');

module.exports = (router) => {
    router.route('/rover/configure').post(controller.configure)
    router.route('/rover/move').post(controller.move);
    router.route('/rover/status').get(controller.status);
};